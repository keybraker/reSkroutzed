export enum Language {
    ENGLISH,
    GREEK,
}